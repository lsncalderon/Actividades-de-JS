//Simulador de venta de productos para el hogar con o sin Gift card de descuento en tu compra//

//Variable del codigo Gift card

let giftCard = "1234-5678";

alert ("Bienvenidos a tienda Luco, encontraras cosas lindas para tu hogar.")

let acceso= prompt("¿Tienes una GiftCard de regalo?. Ingresá el código.")
    if(acceso === giftCard){
        alert ("Tienes un cupón de descuento por 3000 pesos.")
        giftCard=true;
    }
    else {
        alert ("No tienes un cupón de descuento, no te preocupes puedes continuar tu compra.")
        giftCard=false;
    }

//Funcion de compra
function compraLuco (){
    let valorGift = 3000;
    let valorMaceta = 6500;
    let valorPortavasos =4500;
    let opciones = prompt ("Elegí una de las opciones del menú:\n\n1-Macetas: 6500 pesos \n2-Portavasos cuadrados: 4500 pesos \n\nEscribe -Salir- si no deseas comprar")

    while (opciones != "Salir" && opciones != " "){

        if (opciones == "1" && giftCard == true){
            let valorTotal = valorMaceta-valorGift
            alert (`El precio total de tu compra es: ${valorTotal} pesos`);
        }
        else if (opciones == "1" && giftCard == false){
            alert (`El precio total de tu compra es: ${valorMaceta} pesos`);
        }
        else if (opciones == "2" && giftCard == true){
            let valorTotal = valorPortavasos-valorGift
            alert (`El precio total de tu compra es: ${valorTotal} pesos`);
        }
        else if (opciones == "2" && giftCard == false){
            alert (`El precio total de tu compra es: ${valorPortavasos} pesos`);
        }
        else {
            alert ("Ninguna de las opciones es correcta");
        }
        opciones = prompt ("Elegí una de las opciones del menú: \n1-Macetas: 6500 pesos \n2-Portavasos cuadrados: 4500 pesos \n\nEscribe -Salir- si no deseas comprar")
    }
    alert('Gracias por tu visita. ¡Vuelve pronto!');
}
    
compraLuco();

