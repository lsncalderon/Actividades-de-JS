let identificar = true
do{
    let dni = prompt("Ingrese su DNI")
    let contrasena =prompt("Ingrese su contraseña")
    if (dni === "" || contrasena === ""){
        break
    }
    if (dni == "34783169" && contrasena == "1234"){
    alert ("El DNI y contraseña ingresada son correctas")
identificar=false    
}
    else {
    alert ("El DNI y/o contraseña ingresada son incorrectos, ingreselos nuevamente")
    }    
}
while(identificar)
